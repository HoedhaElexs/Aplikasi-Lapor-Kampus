<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Batar extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}


	public function index()
	{
		$this->load->view('hitung_datar');
	}
	public function persegi()
	{
		$this->load->view('persegi');
	}
	public function persegi_panjang()
	{
		$this->load->view('persegi_panjang');
	}
	public function segitiga()
	{
		$this->load->view('segitiga');
	}
	public function trapesium()
	{
		$this->load->view('trapesium');
	}
	public function layang()
	{
		$this->load->view('layang');
	}
	public function ketupat()
	{
		$this->load->view('ketupat');
	}
	public function lingkaran()
	{
		$this->load->view('lingkaran');
	}

}

/* End of file batar.php */
/* Location: ./application/controllers/batar.php */