<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hitung_batar extends CI_Controller {

public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}
	public function index(){

		$this->load->view('hitung_datar');
	}

	public function persegi()
	{
		
		$angka1= $this->input->post('angka1');
	
		$keliling=$angka1*4;
		$luas=$angka1*$angka1;

		$data['keliling']=$keliling;
		$data['luas']=$luas;
		$this->load->view('hasil_datar',$data);

	}
	

	public function persegi_panjang()
	{
		
		$angka1= $this->input->post('angka1');
		$angka2= $this->input->post('angka2');
	
		$luas=$angka1*$angka2;
		$keliling=2*($angka1+$angka2);

		$data['keliling']=$keliling;
		$data['luas']=$luas;
		$this->load->view('hasil_datar',$data);

	}
	public function segitiga()
	{
		
		$angka1= $this->input->post('angka1');
		$angka2= $this->input->post('angka2');
	
		$luas=$angka1*$angka2*0.5;
	

	
		$data['luas']=$luas;
		$this->load->view('hasil_segitiga',$data);

	}
	public function trapesium()
	{
		
		$angka1= $this->input->post('angka1');
		$angka2= $this->input->post('angka2');
		$angka3= $this->input->post('angka3');
	
		$luas=($angka1+$angka2)*0.5*$angka3;
	

	
		$data['luas']=$luas;
		$this->load->view('hasil_segitiga',$data);

	}
	public function layang()
	{
		
		$angka1= $this->input->post('angka1');
		$angka2= $this->input->post('angka2');
		
	
		$luas=$angka1*$angka2*0.5;
	

	
		$data['luas']=$luas;
		$this->load->view('hasil_segitiga',$data);

	}
	public function ketupat()
	{
		
		$angka1= $this->input->post('angka1');
		$angka2= $this->input->post('angka2');
		
	
		$luas=$angka1*$angka2*0.5;
	

	
		$data['luas']=$luas;
		$this->load->view('hasil_segitiga',$data);

	}
	public function lingkaran()
	{
		
		$angka1= $this->input->post('angka1');
	
		
	
		$luas=$angka1*$angka1*3.14;
	

	
		$data['luas']=$luas;
		$this->load->view('hasil_segitiga',$data);

	}

}

/* End of file hitung_batar.php */
/* Location: ./application/controllers/hitung_batar.php */