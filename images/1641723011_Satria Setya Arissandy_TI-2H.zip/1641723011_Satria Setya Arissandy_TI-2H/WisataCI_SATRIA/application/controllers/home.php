<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
	}


	public function index()
	{
		$this->load->view('home');
	}
	public function about()
	{
		$this->load->view('about');
	}
	public function contact()
	{
		$this->load->view('contact');
	}
	
	public function wisata()
	{
		$this->load->view('wisata');
	}
	public function sempu()
	{
		$this->load->view('sempu');
	}
		public function omah()
	{
		$this->load->view('omah');
	}
	public function paralayang()
	{
		$this->load->view('paralayang');
	}
	public function bns()
	{
		$this->load->view('bns');
	}
	public function alun()
	{
		$this->load->view('alun');
	}
	public function terjun()
	{
		$this->load->view('terjun');
	}
}



/* End of file home.php */
/* Location: ./application/controllers/home.php */