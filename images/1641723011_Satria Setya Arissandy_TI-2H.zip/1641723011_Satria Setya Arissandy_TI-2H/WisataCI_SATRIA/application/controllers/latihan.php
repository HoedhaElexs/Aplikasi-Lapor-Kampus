<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class latihan extends CI_Controller {

	
	public function index()
	{
		echo "Hello word ini latihan.php";
	}
}
