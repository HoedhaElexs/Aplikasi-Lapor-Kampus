<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kalkulator CI</title>
</head>
<body>
	<form action="<?php echo site_url('calculator/hasil_hitung'); ?>" method="POST">
		angka pertama : &nbsp <input type="text" name="angka1"/><br/><br/>
		angka kedua : &nbsp&nbsp&nbsp <input type="text" name="angka2"/><br/><br/>
		<select name="pilih hitung">
		<option value="+">+</option>
		<option value="-">-</option>
		<option value="*">*</option>
		<option value="/">/</option>
			
		</select><br/><br/>
		<input type="submit" value="hitung">
	</form>
</body>
</html>