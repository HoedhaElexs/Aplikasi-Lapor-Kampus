
<?php $this->load->view('header'); ?>

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h1>Wisata</h1>
        <h3>Pulau Sempu</h3>
        <img src="../../images/foto.jpg" width="1000px" height="720">
        <p>Untuk menuju ke pantai 3 warna silahkan pilih ke  arah kiri ke pantai Sendang Biru. Jangan belok-belok sampai bertemu papan nama pantai clungup, ikuti saja sampai nanti akan masuk ke sebuah wilayah pedesaan , nanti disana sudah tersedia kantor Clungup Mangrove Conservation (sebelum Bank BRI). Biasanya pengunjung akan diarahkan untuk istirahat di pantai clungkup sebelum trecking ke pantai 3 warna.
        </p>
      </div>

    </div> <!-- /container -->
<?php $this->load->view('footer'); ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
