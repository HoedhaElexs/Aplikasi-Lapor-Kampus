
<?php $this->load->view('header'); ?>

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h1>Biodata</h1>
        <p>Nama: Satria Setya Arissandy<br>
      NIM:1641723011<br>
      Jurusan/Prodi: Teknologi Informasi/Tek.Informatika
     Tgl Lahir: 17 Februari 1996<br>
     Alamat: Jalan Trowulan No.18 Blitar

        </p>
       
      </div>

    </div> <!-- /container -->
<?php $this->load->view('footer'); ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
