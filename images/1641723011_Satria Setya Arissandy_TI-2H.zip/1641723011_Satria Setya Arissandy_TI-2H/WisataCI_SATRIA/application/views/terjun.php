 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Air Terjun Sumber Pitu</h1>
               <img src="../../images/terjun.jpg" width="720px" height="500">
              <p>Tepatnya tempat ini berada di daerah Desa Duwetkrajan, Kecamatan Tumpang, Malang. Jika ingin sampai kesini kamu bisa menggunakan kendaraan roda 2 atau roda empat (kalau bisa menggunakan kendaraan pribadi).</p><p>

Dari pasar tumpang, kamu bisa mengambil arah ke kawasan wisata Taman Nasional Bromo Tengger Semeru. Sampai di Desa Wringinanom Kec. Poncokusumo kemudian kamu belok ke kiri dan masuk kawasan Desa Duwetkrajan. Sampai di Balai Desa Duwetkrajankamu bisa memarkirkna kendaraanmu dan kemudian melanjutkan perjalannan dengan cara berjalanan kaki. Karena tidak di mungkinkannya kamu kendaraan bermotor buat masuk sampai air terjun ini.</p><p>

Gaperlu khawatir buat kamu yang gabisa bawa kendaraan pribadi, kamu bisa menggunakan kendaraan umum, dari pasar Tumpang naik angkutan kota jurusan ke Gubugklakah kemudian turun di pertigaan balai desa Wringinanom. Sesampai disini kamu bisa lihat spanduk dan foto air terjun Sumber Pitu Tumpang yang hanya berjarak sekitar 3 km. Dari sini, kamu harus belok kiri sampai menemui Balai Desa Duwet Krajan, Selanjutnya kamu bisa melanjutkan perjalanan kaki sekitar 2 km dengan pemandangan aliran sungai dan kalau kamu beruntung bisa ketemu sama monyet liar.</p><p>

Bukan itu saja, sebelum kamu sampapai lokasi air terjun cosumber pitu, kamu bisa lihat satu aliran dari air terjun lainnya yang letaknya berada di bagian bawah dan dinamai Cobal Tunggal.</p><p>

Dengan aliran yang cukup dera kamu bisa melihatnya dari jalan setapak, sampai kamu mencapai titik air terjun di bagian depan ini tinggal menoleh ke kiri maka menemui Coban Sumber Pitu. Aliran dari Coban Tunggal ini jaraknya sekitar 150 meter dari Sumber Pitu yang kemudian akan bertemu pada aliran sungai yang sama. Inilah yang disebut air terjun di titik ketiga.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>