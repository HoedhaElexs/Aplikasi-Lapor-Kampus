
<?php $this->load->view('header'); ?>

      <!-- Main component for a primary marketing message or call to action -->
     <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>About Us</h1>
               <img src="../../images/foto.jpg" width="720px" height="500">
             <p>Nama: Satria Setya Arissandy<br>
      NIM:1641723011<br>
      Jurusan/Prodi: Teknologi Informasi/Tek.Informatika
     Tgl Lahir: 17 Februari 1996<br>
     Alamat: Jalan Trowulan No.18 Blitar

        </p>
          </div>

</div>
</div>
</div> <!-- /container -->
<?php $this->load->view('footer'); ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
