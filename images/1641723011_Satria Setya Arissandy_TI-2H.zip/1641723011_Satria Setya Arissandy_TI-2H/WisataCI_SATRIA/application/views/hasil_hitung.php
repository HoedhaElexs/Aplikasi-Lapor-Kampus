<h1>Hasil Perhitungan</h1>
<h3>
	<?php echo $angka1.$pilih_hitung.$angka2."=".$hasil_hitung ?>
</h3>
<a href="<?php echo site_url('calc/'); ?>"><< kembali menghitung </a>