
<?php $this->load->view('header'); ?>

      <!-- Main component for a primary marketing message or call to action -->
     <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Welcome!</h1>
            <p>Ini adalah website untuk mendapatkan info wisata di Malang. Silahkan nikmati petualangan yang menakjubkan di 
             Malang</p>
          </div>
          <div class="row">
            <div class="col-xs-6 col-lg-4">
              <h2>Pulau Sempu</h2>
              <img src="<?php echo base_url()?>images/sempu.jpg" width="250px" height="150">
              <p>Status pulau sempu sendiri merupakan wilayah cagar alam, dalam artian memiliki perlindungan dari pihak perhutani. Sebenarnya pulau sempu bukan dijadikan tempat wisata, hanya untuk kegiatan penelitian supaya bisa diberi izin masuk. </p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/sempu'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
            <div class="col-xs-6 col-lg-4">
            <h2>Omah Kayu</h2>
              <img src="<?php echo base_url()?>images/omah-kayu.jpg" width="250px" height="150">
              <p>
                Omah Kayu Rumah Pohon Batu Malang Jawa Timur. Perkenalkan taman wisata gunung banya (batu, jawa timur) yang memiliki wisata paralayang, flying fox dan pemandangan menakjubkan dari sang pencipta alam semesta. Disini merupakan tempat referensi...
              </p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/omah'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
            <div class="col-xs-6 col-lg-4">
             <h2>Paralayang</h2>
              <img src="<?php echo base_url()?>images/paralayang.jpg" width="250px" height="150">
              <p>Paralayang batu malang jawa timur wisata adrenalin merupakan wisata yang lokasinya dekat dengan kecamatan pujon terutama air terjun coban rondo yang bisa kita kunjungi di satu daerah sekaligus. Banyak pengunjung dari wisata paralayang setiap</p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/paralayang'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
            <div class="col-xs-6 col-lg-4">
            <h2>BNS</h2>
              <img src="<?php echo base_url()?>images/bns.jpg" width="250px" height="150">
              <p>Batu Night Spectacular BNS Malang Jawa Timur, merupakan objek pariwisata malam dengan konsep suasana hiburan keluarga yang terintegrasi memadukan konsep mall, market, permainan, sport </p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/bns'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
            <div class="col-xs-6 col-lg-4">
              <h2>Alun-Alun</h2>
              <img src="<?php echo base_url()?>images/alun.jpg" width="250px" height="150">
              <p>Alun-alun kota Batu Malang Jawa Timur Terbaru adalah satu dari dua alun-alun yang dimiliki Malang. Alun-alun ini juga disebut dengan Alun-alun Jami’ karena letaknya tepat di depan Masjid Jami’ </p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/alun'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
            <div class="col-xs-6 col-lg-4">
              <h2>Sumber Pitu</h2>
              <img src="<?php echo base_url()?>images/terjun.jpg" width="250px" height="150">
              <p>Destinasi satu ini merupakan salah satu lokasi yang masih jarang sekali diketahui wisatawan jadi masih sedikit pengunjungnya, namun memiliki pemandangan yang indah sekali,namanya sumber pitu atau</p>
              <p><a class="btn btn-default" href="<?php echo site_url('home/terjun'); ?>" role="button">View details &raquo;</a></p>
            </div><!--/.col-xs-6.col-lg-4-->
          </div><!--/row-->
        </div><!--/.col-xs-12.col-sm-9-->

        -/.sidebar-offcanvas-->
      </div><!--/row-->
 <!-- /container -->
<?php $this->load->view('footer'); ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
