<h1>Hasil Perhitungan</h1>
<h3>
	Luas: <?php echo $luas ?> <br/>
	
</h3>
<a href="<?php echo site_url('batar/'); ?>"><< kembali menghitung </a>