 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Pulau Sempu</h1>
               <img src="../../images/sempu.jpg" width="720px" height="500">
              <p>Status pulau sempu sendiri merupakan wilayah cagar alam, dalam artian memiliki perlindungan dari pihak perhutani. Sebenarnya pulau sempu bukan dijadikan tempat wisata, hanya untuk kegiatan penelitian supaya bisa diberi izin masuk.

Tetapi dilema antara kepentingan masyarakat yang menjadikan pulau sempu sebagai tempat wisata menjadi mata pencaharian sebagian besar masyarakat pesisir. Salah satunya dengan memberikan jasa antar jemput wisatawan menyebrang dari sendang biru sampai pulau sempu sebelum memulai perjalanan menuju segara anakan.</p>
<p>Disebuah pulau kecil tak berpenghuni ini, kita akan disuguhkan dengan panorama sangat indah dibalik tampilan luar pulau yang nampak sedikit angker dengan jalan yang dikelilingi karang tajam. Tetapi memiliki laguna jernih nan cantik dan pasir putih yang siap menyihir pandangan mata para wisatawan. Pulau yang terletak di Desa Tambak Rejo Desa, Kecamatan Sumbermanjing Wetan, Kabupaten Malang tersebut semakin banyak dikunjungi oleh para wisatawan. Keindahan yang menjadi magnet para wisatawan.

Bagi kamu yang mau melakukan perjalanan di pulau sempu menuju segara anakan, maka sebaiknya dipersiapkan matang-matang akan semua keperluan. Dalam pulau tak berpenghuni sudah pasti tidak akan ada orang berjualan disana, sehingga Anda membutuhkan perbekalan makanan lebih dari perkiraan.

Karena dalam segara anakan ini meski memiliki air yang cukup jernih, tetap saja air di segara ini merupakan air asin yang datang dari laut sehingga tidak bisa digunakan untuk konsumsi.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>