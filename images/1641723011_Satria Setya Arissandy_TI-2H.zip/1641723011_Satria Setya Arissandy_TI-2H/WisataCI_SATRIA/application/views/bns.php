 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Batu Night Spectacular</h1>
               <img src="../../images/bns.jpg" width="720px" height="500">
              <p>Batu Night Spectacular BNS Malang Jawa Timur, merupakan objek pariwisata malam dengan konsep suasana hiburan keluarga yang terintegrasi memadukan konsep mall, market, permainan, sport dan hiburan dalam satu tempat dan ruang baru yang ada di daerah Oro-Oro Ombo.
<p>Batu Night Spectacular ingin menghidupkan suasana malam kota Batu dengan menghadirkan wahana-wahana yang spektakuler mulai dari wahana yang mengasyikan, menyeramkan, sampai wahana yang menantang yang siap menguji adrenalin kamu.</p>

<p>
Sehingga Batu Night Spectacular menjadi salah satu wisata favorit bagi wisatawan yang ingin menikmati indahnya suasana kota malang dengan kelap-kelip lampu yang berlokasi di dataran tinggi dengan hawa yang sejuk.</p>
<p>
Karena di Sesuai dengan namanya, tempat ini memang menyajikan keindahan wisata malam di kota Batu dengan suasana sejuk pegunungan. Kamu bakal dimanjakan dengan tata lampu yang indah di Batu Night Spectacular.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>