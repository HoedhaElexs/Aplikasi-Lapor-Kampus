 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Omah Kayu</h1>
               <img src="../../images/omah-kayu.jpg" width="720px" height="500">
              <p>Omah Kayu Rumah Pohon Batu Malang Jawa Timur. Perkenalkan taman wisata gunung banya (batu, jawa timur) yang memiliki wisata paralayang, flying fox dan pemandangan menakjubkan dari sang pencipta alam semesta. Disini merupakan tempat referensi untuk kamu yang pengen menikmati suasana perdesaan tenang, sunyi dan nyaman.</p>
<p>Dan tempat peristirahatan ini dinamai dengan omah kayu (rumah pohon) yang terletak di Batu Malang dengan tempat peristirahatan yang berukuran 3×2 meter yang terbuat dari kayu dan berada di batang pohon pinus yang hidup dengan ketinggian 10 meter dari akarnya. Ruang kamar dan balkon terbuat dari kayu eukapiliptusa, kausarina, dan pinus.</p>
<p>Omah kayu hanya bisa menampung 2 hingga 3 orang pengunjung dalam setiap kamarnya. Jika kamu ingin naik ke atas ada tangga kayu untu menuju tiap-tiap kamar yang menghadap ke timur. Saat ini baru tersedia enam unit kamar di Omah Kayu.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>