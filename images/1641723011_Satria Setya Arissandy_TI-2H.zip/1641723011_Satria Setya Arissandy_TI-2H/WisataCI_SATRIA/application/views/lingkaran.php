<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kalkulator CI</title>
</head>
<body>
	<form action="<?php echo site_url('hitung_batar/lingkaran'); ?>" method="POST">
	Jari-jari : &nbsp <input type="text" name="angka1"/><br/><br/>
		
		
			
		</select><br/><br/>
		<input type="submit" value="hitung">
	</form>
</body>
</html>