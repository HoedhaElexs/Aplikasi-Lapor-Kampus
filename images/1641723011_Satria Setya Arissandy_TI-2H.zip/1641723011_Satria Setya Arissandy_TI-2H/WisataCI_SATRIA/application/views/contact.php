
<?php $this->load->view('header'); ?>

        <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Contact</h1>
        
             <p>No HP: 085790384993  </p>
              <p>Email: satryasetya@gmail.com  </p>
                <p>Instagram: arissandysatrya  </p>
          </div>

</div>
</div>
</div> <!-- /container -->
<?php $this->load->view('footer'); ?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   
