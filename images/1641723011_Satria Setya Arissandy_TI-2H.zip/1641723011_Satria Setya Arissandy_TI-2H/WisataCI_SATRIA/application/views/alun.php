 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Alun-alun</h1>
               <img src="../../images/alun.jpg" width="720px" height="500">
              <p>Alun-alun kota Batu Malang Jawa Timur Terbaru adalah satu dari dua alun-alun yang dimiliki Malang. Alun-alun ini juga disebut dengan Alun-alun Jami’ karena letaknya tepat di depan Masjid Jami’ yang merupakan masjid kebanggaan warga Malang. Sedangkan alun-alun yang satunya lagi bernama Alun-Alun Bundar karena memang bentuknya lingkaran dan alun-alun ini terletak tepat di depan Balai Kota.</p>
<p>
Taman ini menjadi saksi perkembangan Kota Malang sejak dikuasai kaum Kolonial Belanda. Termasuk ketika status Malang berubah menjadi Kota Madya di tahun 1914. Begitu pula saat dibangunnya gedung Balai Kota pada tahun 1930-an di sisi sebelah selatan taman. Pembangunan gedung pusat pemerintahan Kota Malang itu menjadi bagian dari rencana perluasan kota atau disebut Bouwplan.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>