 <?php $this->load->view('header'); ?>
 <div class="container">

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          <div class="jumbotron">
            <h1>Paralayang</h1>
               <img src="../../images/paralayang.jpg" width="720px" height="500">
              <p>Paralayang batu malang jawa timur wisata adrenalin merupakan wisata yang lokasinya dekat dengan kecamatan pujon terutama air terjun coban rondo yang bisa kita kunjungi di satu daerah sekaligus. Banyak pengunjung dari wisata paralayang setiap harinya, dimulai dari turis mancanegara sampai wisatawan lokal dan kebanyakan dari pengunjung ini hanya sekedar berfoto ria dengan pemandangan lokasi wisata paralayang yang keren nan menakjubkan.

Disini kamu bisa menuju lokasi paralayang menggunakan kendaraan pribadi seperti mobil atau motor. Ini nih khusus buat kamu yang membawa mobil dan baru pertama kalinya kesini kamu wajib berhati-hati karena lokasi medan jalannya menanjak naik dan menanjak turun ditambah lagi dengan jalan di hutan yang berbelok-belok akan sedikit menyulitkan, tapi tetap asyik menikmati perjalanan.</p>
          </div>

</div>
</div>
</div>

          <?php $this->load->view('footer'); ?>