<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kalkulator CI</title>
</head>
<body>
	<form action="<?php echo site_url('hitung_batar/segitiga'); ?>" method="POST">
	Alas : &nbsp <input type="text" name="angka1"/><br/><br/>
	Tinggi : &nbsp <input type="text" name="angka2"/><br/><br/>
		
		
			
		</select><br/><br/>
		<input type="submit" value="hitung">
	</form>
</body>
</html>