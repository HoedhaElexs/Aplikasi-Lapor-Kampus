<h1>Pilih Bangun</h1>

<a href="<?php echo site_url('batar/persegi'); ?>"><< Persegi </a><br />
<a href="<?php echo site_url('batar/persegi_panjang'); ?>"><< Persegi Panjang </a><br />
<a href="<?php echo site_url('batar/segitiga'); ?>"><< Segitiga </a><br />
<a href="<?php echo site_url('batar/trapesium'); ?>"><< Trapesium </a><br />
<a href="<?php echo site_url('batar/layang'); ?>"><< layang</a><br />
<a href="<?php echo site_url('batar/ketupat'); ?>"><< ketupat </a><br />
<a href="<?php echo site_url('batar/lingkaran'); ?>"><< lingkaran</a><br />