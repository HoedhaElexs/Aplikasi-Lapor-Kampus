<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kalkulator CI</title>
</head>
<body>
	<form action="<?php echo site_url('hitung_batar/ketupat'); ?>" method="POST">
	Diagonal 1 : &nbsp <input type="text" name="angka1"/><br/><br/>
	Diagonal 2 : &nbsp <input type="text" name="angka2"/><br/><br/>
		
		
			
		</select><br/><br/>
		<input type="submit" value="hitung">
	</form>
</body>
</html>